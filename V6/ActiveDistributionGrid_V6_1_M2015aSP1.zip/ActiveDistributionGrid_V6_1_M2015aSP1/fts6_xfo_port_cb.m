function nn=fts6_xfo_port_cb(block,conntyp)
% this is the callback function of the SSN custom coded saturable transformer
%conntyp                          status
%4 ports                           4
%3 ports (left grounded)           31
%3 ports (right grounded)          32
%2 ports                           2

ab_ports=find_system(block,'LookUnderMasks', 'all','SearchDepth',1,'BlockType','PMIOPort');
err=0;
current_status=get_param([block '/current_status'],'Value');

if isequal(conntyp,'4 ports')
    next_status='4';
    nn='4';
elseif isequal(conntyp,'3 ports (primary grounded)')
    next_status='31';
    nn='3';
elseif isequal(conntyp,'3 ports (tapped secondary grounded)')
    next_status='32';
    nn='3';
elseif isequal(conntyp,'2 ports')
    next_status='2';
    nn='2';
else
    next_status='4'; % error...
    nn='4';
    err=1;
end
   
if err==1
    connect_all(block);
    return;
end
if isequal(current_status,next_status)
    return;
end


% being by putting back all lines and blocks
connect_all(block);
    
% then delete parts

if isequal(conntyp,'3 ports (primary grounded)')  
     delete_right(block);
elseif isequal(conntyp,'3 ports (tapped secondary grounded)')  
    
    delete_left(block);
elseif isequal(conntyp,'2 ports')
    delete_left(block);
    delete_right(block);
else
end

set_param([block '/current_status'],'Value', next_status);

function delete_right(block)
    handleBlock1 = get_param([block '/c'], 'Handle');
    pb = get_param(handleBlock1, 'PortHandles'); 
    line=get(pb.RConn(1));
    linea=line.Line;
    delete_line(linea);
    delete_block([block '/c']);
    
    handleBlock2 = get_param([block '/I1C'], 'Handle');
    pib = get_param(handleBlock2, 'PortHandles'); 
    line=get(pib.RConn(1));
    linea=line.Line;
    delete_line(linea);
    line=get(pib.LConn(1));
    linea=line.Line;
    delete_line(linea);
    delete_block([block '/I1C']);
    
 function delete_left(block)
    handleBlock1 = get_param([block '/d'], 'Handle');
    pb = get_param(handleBlock1, 'PortHandles'); 
    line=get(pb.RConn(1));
    linea=line.Line;
    delete_line(linea);
    delete_block([block '/d']);
    
    handleBlock2 = get_param([block '/I1D'], 'Handle');
    pib = get_param(handleBlock2, 'PortHandles'); 
    line=get(pib.RConn(1));
    linea=line.Line;
    delete_line(linea);
    line=get(pib.LConn(1));
    linea=line.Line;
    delete_line(linea);
    delete_block([block '/I1D']);
    
 function connect_all(block)
   try
    b_block=add_block([block '/a'], [block '/c']);
    pos=get_param(b_block,'Position');
    pos=pos+[0 120 0 120];  % offset the block lower
    set_param(b_block,'Position', pos);
    set_param(b_block,'Port','3');
    set_param(b_block,'Side','Left');
    handleBlock1 = get_param([block '/c'], 'Handle');
    pb = get_param(handleBlock1, 'PortHandles'); 
    handleBlock2 = get_param([block '/DC source_c'], 'Handle');
    pdc = get_param(handleBlock2, 'PortHandles');
    add_line(block, pdc.RConn(1), pb.RConn(1));
    
    ib_block=add_block([block '/I1A'], [block '/I1C']);
    pos=get_param(ib_block,'Position');
    pos=pos+[ 150 10 150 10];  % offset the block lower
    set_param(ib_block,'Position', pos);
    
    handleBlock1 = get_param([block '/I1C'], 'Handle');
    pib = get_param(handleBlock1, 'PortHandles'); 
    handleBlock2 = get_param([block '/conn_up_c'], 'Handle');
    pcu = get_param(handleBlock2, 'PortHandles');
    add_line(block, pcu.RConn(1), pib.RConn(1));
    
    handleBlock3 = get_param([block '/conn_down_c'], 'Handle');
    pcd = get_param(handleBlock3, 'PortHandles');
    add_line(block, pcd.LConn(1), pib.LConn(1));
    
catch 
end
try
    d_block=add_block([block '/b'], [block '/d']);
    pos=get_param(d_block,'Position');
    pos=pos+[0 120 0 120];  % offset the block lower
    set_param(d_block,'Position', pos);
    handleBlock1 = get_param([block '/d'], 'Handle');
    set_param(d_block,'Port','4');
    set_param(d_block,'Side','Right');
    pb = get_param(handleBlock1, 'PortHandles'); 
    handleBlock2 = get_param([block '/DC source_d'], 'Handle');
    pdc = get_param(handleBlock2, 'PortHandles');
    add_line(block, pdc.RConn(1), pb.RConn(1));
    
    id_block=add_block([block '/I1B'], [block '/I1D']);
    pos=get_param(id_block,'Position');
    pos=pos+[ 150 10 150 10];  % offset the block lower
    set_param(id_block,'Position', pos);
    
    handleBlock1 = get_param([block '/I1D'], 'Handle');
    pib = get_param(handleBlock1, 'PortHandles'); 
    handleBlock2 = get_param([block '/conn_up_d'], 'Handle');
    pcu = get_param(handleBlock2, 'PortHandles');
    add_line(block, pcu.RConn(1), pib.RConn(1));
    
    handleBlock3 = get_param([block '/conn_down_d'], 'Handle');
    pcd = get_param(handleBlock3, 'PortHandles');
    add_line(block, pcd.LConn(1), pib.LConn(1));
catch 
end

